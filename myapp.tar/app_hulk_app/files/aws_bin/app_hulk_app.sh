#!/bin/bash

USERDATA=/cust/templates/aws-user-data.txt
IAM=/cust/templates/IAMcred.txt

curl http://169.254.169.254/latest/user-data/ > $USERDATA

PROXYLIST="$(grep "PROXYLIST=" $USERDATA | sed 's/PROXYLIST=//')"
AWSACCESSKEY="$(grep "AccessKeyId" $IAM | awk '{ print $3}'| sed 's/,*$//'| sed -e 's/^"//'  -e 's/"$//')"
AWSSECRETKEY="$(grep "SecretAccessKey" $IAM | awk '{ print $3}'| sed 's/,*$//'| sed -e 's/^"//'  -e 's/"$//')"

JBOSS_XML=/cust/puppet/appeng/modules/app_hulk_app/templates/aws-standalone-full-ha.xml.erb

S3PING="$(grep "S3PING=" $USERDATA | sed 's/export S3PING=//')"

sed -i "s/BUCKETNAME/$S3PING/g"      $JBOSS_XML
sed -i "s/PROXYLIST/$PROXYLIST/g"    $JBOSS_XML
sed -i "s%SECRETKEY%$AWSSECRETKEY%g" $JBOSS_XML
sed -i "s/ACCESSKEY/$AWSACCESSKEY/g" $JBOSS_XML

JBOSS_DEP=/cust/puppet/appeng/modules/app_hulk_app/files/jboss/home/bin/deploy_eap6.sh

UVN_ENV="$(grep "UVN_ENV=" $USERDATA | sed 's/export UVN_ENV=//')"

sed -i "s/REPLACE_UVN_ENV/$UVN_ENV/g" $JBOSS_DEP 

/usr/bin/puppet apply --modulepath=/cust/puppet/appeng/modules -e "include app_hulk_app"

exit 0;
